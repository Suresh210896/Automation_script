const { test, expect } = require('@playwright/test');

test('test', async ({ page }) => {
  await page.goto('https://www.google.com/search?q=amazon&oq=amazon&gs_lcrp=EgZjaHJvbWUyBggAEEUYOdIBCDI2OTFqMGoxqAIAsAIB&sourceid=chrome&ie=UTF-8');

  // Click on the link for the Amazon Great Indian Festival
  await page.getByRole('link', { name: 'Amazon Great Indian Festival' }).click();

  // Select the department
  await page.getByLabel('Select the department you').selectOption('search-alias=fashion');

  // Click the Go button
  await page.getByRole('button', { name: 'Go', exact: true }).click();

  // Click on the Luggage & Bags link
  await page.getByRole('link', { name: 'Luggage & Bags Luggage & Bags' }).click();

  // Click on a specific brand (Skyabgs)
  await page.getByRole('link', { name: 'Skyabgs' }).click();

  // Wait for the popup and click on the product image
  const popupPromise = page.waitForEvent('popup');
  await page.locator('div:nth-child(7) > .sg-col-inner > .s-widget-container > span > .puis-card-container > div > .s-product-image-container > .s-image-padding > .rush-component > .a-link-normal').click();
  const popupPage = await popupPromise;

  // Add the item to the cart
  await popupPage.getByLabel('Add to Cart').click();

  // Click on the cart icon or link (adjust the selector accordingly)
  await page.getByLabel('item in cart').click();
});